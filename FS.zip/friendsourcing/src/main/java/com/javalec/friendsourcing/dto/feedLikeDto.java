package com.javalec.friendsourcing.dto;

public class feedLikeDto {
	private int feed_feNum;
	private String member_memId;
	
	public feedLikeDto() {
	}
	
	public feedLikeDto(int feed_feNum, String member_memId) {
		this.feed_feNum = feed_feNum;
		this.member_memId = member_memId;
	}

	public int getFeed_feNum() {
		return feed_feNum;
	}
	public void setFeed_feNum(int feed_feNum) {
		this.feed_feNum = feed_feNum;
	}
	public String getMember_memId() {
		return member_memId;
	}
	public void setMember_memId(String member_memId) {
		this.member_memId = member_memId;
	}
	
	
}
