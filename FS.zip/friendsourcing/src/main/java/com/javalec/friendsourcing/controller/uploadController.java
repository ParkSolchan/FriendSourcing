package com.javalec.friendsourcing.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.javalec.friendsourcing.dto.FeedDto;
import com.javalec.friendsourcing.dto.FeedimgDto;
import com.javalec.friendsourcing.dto.memberDto;
import com.javalec.friendsourcing.service.serviceTG;

import lombok.extern.log4j.Log4j2;
import net.coobird.thumbnailator.Thumbnailator;

@Controller
@Log4j2
public class uploadController {
	@Autowired
	private serviceTG service;
	
	@PostMapping(value = "/uploadAjaxAction", produces = "application/json; charset=utf8")
	@ResponseBody
	public ResponseEntity<List<memberDto>> uploadAjaxPost(MultipartFile[] uploadFile,String memId) {
		
		List<memberDto> list = new ArrayList<memberDto>();
		String uploadFolder = "C:\\upload";
		
		String uploadFolerPath = getFolder();
		//make folder ---------
		File uploadPath = new File(uploadFolder,uploadFolerPath);
		
		if (uploadPath.exists() == false) {
			uploadPath.mkdirs();
		}
		System.out.println("uploadPath@@@>>>>>>>>"+uploadPath);
		
		//make yyyy/MM/dd folder
		for (MultipartFile multipartFile : uploadFile) {
//			System.out.println("-----------------------------");
//			System.out.println("Upload File Name: "+multipartFile.getOriginalFilename());
//			System.out.println("Upload File Size: "+multipartFile.getSize());
			
			memberDto memberimgDto = new memberDto();
			
			String uploadFileName = multipartFile.getOriginalFilename();
			
			//ie has file path
			uploadFileName = uploadFileName.substring(uploadFileName.lastIndexOf("\\") + 1);
			String filename = uploadFileName;
			memberimgDto.setFilename(uploadFileName);
			memberimgDto.setMemId(memId);
			
			UUID uuid = UUID.randomUUID();
			
			uploadFileName = uuid.toString()+"_"+uploadFileName;
			
			try {
				File saveFile = new File(uploadPath , uploadFileName);
				multipartFile.transferTo(saveFile);
				
				memberimgDto.setUuid(uuid.toString());
				memberimgDto.setUploadpath(uploadFolerPath);
				
				//check image type file
				if (/*checkImageType(saveFile)*/ true) {
					
					
					FileOutputStream thumbnail = new FileOutputStream(new File(uploadPath, "s_"+uploadFileName));
					Thumbnailator.createThumbnail(multipartFile.getInputStream(), thumbnail, 100, 100);
					thumbnail.close();
				}
				
				service.fileUpload(uploadFolerPath,uuid.toString(),filename,memId);
				
				//add to list
				list.add(memberimgDto);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return new ResponseEntity<List<memberDto>>(list, HttpStatus.OK);
	}
	
	@PostMapping(value = "/uploadAjaxFeed", produces = "application/json; charset=utf8")
	@ResponseBody
	public ResponseEntity<List<FeedimgDto>> uploadAjaxFeed(MultipartFile[] uploadFile) {
		
		List<FeedimgDto> list = new ArrayList<FeedimgDto>();
		String uploadFolder = "C:\\upload";
		
		String uploadFolerPath = getFolder();
		//make folder ---------
		File uploadPath = new File(uploadFolder,uploadFolerPath);
		
		if (uploadPath.exists() == false) {
			uploadPath.mkdirs();
		}
		System.out.println("uploadPath@@@>>>>>>>>"+uploadPath);
		
		
		//make yyyy/MM/dd folder
		for (MultipartFile multipartFile : uploadFile) {
//			System.out.println("-----------------------------");
			System.out.println("Upload File Name: "+multipartFile.getOriginalFilename());
			System.out.println("Upload File Size: "+multipartFile.getSize());
			
			FeedimgDto feedImg = new FeedimgDto();
			
			String uploadFileName = multipartFile.getOriginalFilename();
			
			//ie has file path
			uploadFileName = uploadFileName.substring(uploadFileName.lastIndexOf("\\") + 1);
			String filename = uploadFileName;
			
			feedImg.setFileName(uploadFileName);
			
			UUID uuid = UUID.randomUUID();
			
			uploadFileName = uuid.toString()+"_"+uploadFileName;
			
			try {
				File saveFile = new File(uploadPath , uploadFileName);
				multipartFile.transferTo(saveFile);
				
				feedImg.setUuid(uuid.toString());
				feedImg.setUploadPath(uploadFolerPath);
				
				//check image type file
				if (/*checkImageType(saveFile)*/ true) {
					
					
					FileOutputStream thumbnail = new FileOutputStream(new File(uploadPath, "s_"+uploadFileName));
					Thumbnailator.createThumbnail(multipartFile.getInputStream(), thumbnail, 100, 100);
					thumbnail.close();
				}
				
				
				/*
				 * HashMap<String, String> param = new HashMap<String, String>();
				 * param.put("var", Integer.toString(var)); param.put("uploadpath",
				 * uploadFolerPath); param.put("filename", filename); param.put("uuid",
				 * uuid.toString()); param.put("feed_fenum", feed_fenum);
				 * 
				 * service.FeedUpload(param);
				 */
				
				//add to list
				list.add(feedImg);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return new ResponseEntity<List<FeedimgDto>>(list, HttpStatus.OK);
	}
	
	//db�� img ��θ� ����
	@RequestMapping(value = "/dbUploadImg")
	@ResponseBody
	public Map<String,Object> dbUploadImg(@RequestParam String data) {
		Map<String, Object> result = new HashMap<String,Object>();
		try {
			List<Map<String, Object>> info = new Gson().fromJson(String.valueOf(data),
		    new TypeToken<List<Map<String, Object>>>(){}.getType());
			
			int var = 0;
			String feed_fenum = service.feedNum();
			for (int i = 0; i < info.size(); i++) {
				var++;
				if (info.get(i).isEmpty()) continue;
				String filename = (String) info.get(i).get("fileName");
				String uuid = (String) info.get(i).get("uuid");
				String uploadFolerPath = (String) info.get(i).get("uploadPath");
				
				HashMap<String, String> param = new HashMap<String,String>();
				param.put("var",Integer.toString(var));
				param.put("filename", filename);
				param.put("uuid", uuid);
				param.put("uploadpath", uploadFolerPath);
				param.put("feed_fenum", feed_fenum);
				service.FeedUpload(param);
			}
			
		    result.put("result", true);
		} catch (Exception e) {
			result.put("result", false);
		}
		  return result; 
	}
	
	//���糯¥�� ������ �������� �ϴ� �޼ҵ�
	private String getFolder() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String str = sdf.format(date);
		return str.replace("-", File.separator);
	}
	
	@GetMapping("/display")
	@ResponseBody
	public ResponseEntity<byte[]> getFile(String fileName) {
		System.out.println("fileName: "+fileName);
		
		File file = new File("c:\\upload\\"+fileName);
		
		System.out.println("file :"+file);
		
		ResponseEntity<byte[]> result = null;
		
		try {
			HttpHeaders header = new HttpHeaders();
			
			header.add("Content-Type", Files.probeContentType(file.toPath()));
			result = new ResponseEntity<byte[]>(FileCopyUtils.copyToByteArray(file),header,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//���� �����ϴ� �޼ҵ�
	@PostMapping("/deleteFile")
	@ResponseBody
	public ResponseEntity<String> deleteFile(String fileName){
		System.out.println("deleteFile: "+fileName);
		File file;
		
		try {
			
			//�̹��� ��������(�����)
			StringBuffer sb = new StringBuffer(fileName);
			sb.insert(17,"s_");
			fileName = sb.toString();
			
			file = new File("c:\\upload\\"+URLDecoder.decode(fileName,"UTF-8"));
			file.delete();
			
			//�׳� ���� ����
			String largeFileName = file.getAbsolutePath().replace("s_", "");
			System.out.println("largeFileName : "+largeFileName);
			file = new File(largeFileName);
			file.delete();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<String>("delete",HttpStatus.OK);
	}
}
