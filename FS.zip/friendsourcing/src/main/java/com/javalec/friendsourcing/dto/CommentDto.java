package com.javalec.friendsourcing.dto;

public class CommentDto {
	private int comnum;
	private String comcontent;
	private int feed_fenum;
	private String member_memid;
	
	public CommentDto() {
		
	}
	
	public CommentDto(int comnum, String comcontent, int feed_fenum, String member_memid) {
		this.comnum = comnum;
		this.comcontent = comcontent;
		this.feed_fenum = feed_fenum;
		this.member_memid = member_memid;
	}
	
	public int getComnum() {
		return comnum;
	}
	public void setComnum(int comnum) {
		this.comnum = comnum;
	}
	public String getComcontent() {
		return comcontent;
	}
	public void setComcontent(String comcontent) {
		this.comcontent = comcontent;
	}
	public int getFeed_fenum() {
		return feed_fenum;
	}
	public void setFeed_fenum(int feed_fenum) {
		this.feed_fenum = feed_fenum;
	}
	public String getMember_memid() {
		return member_memid;
	}
	public void setMember_memid(String member_memid) {
		this.member_memid = member_memid;
	}
	
}
