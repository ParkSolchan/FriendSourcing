package com.javalec.friendsourcing.dto;

public class memberDto {
	private String memId;
	private String memName;
	private String memAddress;
	private double memAddressX;
	private double memAddressY;
	private String memTel;
	private String filename;
	private String uploadpath;
	private String uuid;
	private String memProfile;
	private String pullPath;

	public String getPullPath() {
		return pullPath;
	}

	public void setPullPath(String pullPath) {
		this.pullPath = pullPath;
	}

	public memberDto() {
	}

	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getMemName() {
		return memName;
	}
	public void setMemName(String memName) {
		this.memName = memName;
	}
	public String getMemAddress() {
		return memAddress;
	}
	public void setMemAddress(String memAddress) {
		this.memAddress = memAddress;
	}
	public double getMemAddressX() {
		return memAddressX;
	}
	public void setMemAddressX(double memAddressX) {
		this.memAddressX = memAddressX;
	}
	public double getMemAddressY() {
		return memAddressY;
	}
	public void setMemAddressY(double memAddressY) {
		this.memAddressY = memAddressY;
	}
	public String getMemTel() {
		return memTel;
	}
	public void setMemTel(String memTel) {
		this.memTel = memTel;
	}
	public String getMemProfile() {
		return memProfile;
	}
	public void setMemProfile(String memProfile) {
		this.memProfile = memProfile;
	}


	public String getFilename() {
		return filename;
	}


	public void setFilename(String filename) {
		this.filename = filename;
	}


	public String getUploadpath() {
		return uploadpath;
	}


	public void setUploadpath(String uploadpath) {
		this.uploadpath = uploadpath;
	}


	public String getUuid() {
		return uuid;
	}


	public void setUuid(String uuid) {
		this.uuid = uuid;
	}


	public memberDto(String memId, String memName, String memAddress, double memAddressX, double memAddressY, String memTel, String filename, String uploadpath,
			String uuid, String memProfile) {
		super();
		this.memId = memId;
		this.memName = memName;
		this.memAddress = memAddress;
		this.memAddressX = memAddressX;
		this.memAddressY = memAddressY;
		this.memTel = memTel;
		this.filename = filename;
		this.uploadpath = uploadpath;
		this.uuid = uuid;
		this.memProfile = memProfile;
	}
	
}
