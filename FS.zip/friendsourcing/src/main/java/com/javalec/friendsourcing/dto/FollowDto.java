package com.javalec.friendsourcing.dto;

public class FollowDto {
	private String member_memid;
	private String follower;
	
	public String getMember_memid() {
		return member_memid;
	}
	public void setMember_memid(String member_memid) {
		this.member_memid = member_memid;
	}
	public String getFollower() {
		return follower;
	}
	public void setFollower(String follower) {
		this.follower = follower;
	}
	
	public FollowDto(String member_memid, String follower) {
		super();
		this.member_memid = member_memid;
		this.follower = follower;
	}
	public FollowDto() {
		// TODO Auto-generated constructor stub
	}
}
