package com.javalec.friendsourcing.dto;

import java.util.Date;

public class FeedDto {
	private int fenum;
	private Date fedate;
	private String fecontent;
	private int fescore;
	private String markertype;
	private int place_planum;
	private String member_memid;
	
	
	public FeedDto(int fenum, Date fedate, String fecontent, int fescore, String markertype, int place_planum,
			String member_memid) {
		super();
		this.fenum = fenum;
		this.fedate = fedate;
		this.fecontent = fecontent;
		this.fescore = fescore;
		this.markertype = markertype;
		this.place_planum = place_planum;
		this.member_memid = member_memid;
	}
	
	public FeedDto() {
		// TODO Auto-generated constructor stub
	}
	
	public int getFenum() {
		return fenum;
	}
	public void setFenum(int fenum) {
		this.fenum = fenum;
	}
	public Date getFedate() {
		return fedate;
	}
	public void setFedate(Date fedate) {
		this.fedate = fedate;
	}
	public String getFecontent() {
		return fecontent;
	}
	public void setFecontent(String fecontent) {
		this.fecontent = fecontent;
	}
	public int getFescore() {
		return fescore;
	}
	public void setFescore(int fescore) {
		this.fescore = fescore;
	}
	public String getMarkertype() {
		return markertype;
	}
	public void setMarkertype(String markertype) {
		this.markertype = markertype;
	}
	public int getPlace_planum() {
		return place_planum;
	}
	public void setPlace_planum(int place_planum) {
		this.place_planum = place_planum;
	}
	public String getMember_memid() {
		return member_memid;
	}
	public void setMember_memid(String member_memid) {
		this.member_memid = member_memid;
	}
	
	
}
